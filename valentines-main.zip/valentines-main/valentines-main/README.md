# 💖 Valentines Project 💖

### This is a cute little way you can ask someone to be your valentine! 🌹

## Features
- 🥰 A few adorable Togepi gifs
- ❌ Changing "No" button messages
- 🔄 Resizing buttons after clicking

## How It Works
This project asks your special someone to be their valentine, but we don't let them say no! (Consent is very important, this is very much just a silly for funsies thing that hopefully won't be used to harass anyone!!).

## Clone This Project
1. Clone this repository: `git clone https://github.com/stephanieran/valentines.git`  
2. Open `index.html` in your browser.

## Try It Out & Send it to Someone!
To mess around with this project and get a shareable link, check out this [link on CodeSandbox](temp link) where you can fork the project and modify it however you want (change up the gifs/messages) and grab a link to send to that someone special!
1. Open [CodeSandbox link](https://ffsvgv.csb.app/)
2. Click `Fork` in the upper right corner to create your own copy OR just copy the preview link and send it to your crush!

My only ask is that you let me know what they say!🤭